#' Curve Dnorm
#'
#' @param x  area
#' @param sigma standard deviation
#' @param mu mean
#' @importFrom graphics curve polygon
#' @importFrom stats dnorm pnorm
#'
#' @return Makes a dnorm curved plot
#' @export
#'
#' @examples \dontrun{myncurve(mu,sigma)}
#
  myncurve = function(mu, sigma,a){
    x <- NULL
  curve(dnorm(x,mean=mu,sd=sigma),
  xlim = c(mu-3*sigma, mu + 3*sigma))
  area = pnorm(a, mean=mu, sd=sigma)
  xcurve= seq(mu-3*sigma, a, length=1000)
    ycurve= dnorm(xcurve,mean= mu, sd= sigma)
    polygon(c(mu-3*sigma, xcurve, a), c(0,ycurve,0), color = "Blue")
    return(list(Area=area))

}

